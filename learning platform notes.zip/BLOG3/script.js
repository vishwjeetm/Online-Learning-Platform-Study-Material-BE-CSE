//theme toggle
        document.getElementById('themeToggle').onclick = function() {
            // Toggle theme on body
            document.body.classList.toggle('dark-theme');
            // Optionally, change icon
            this.textContent = document.body.classList.contains('dark-theme') ? '☀️' : '🌙';

            // Apply theme to all iframes
            const iframes = document.querySelectorAll('iframe');
            iframes.forEach(iframe => {
                try {
                    const doc = iframe.contentDocument || iframe.contentWindow.document;
                    if (doc && doc.body) {
                        if (document.body.classList.contains('dark-theme')) {
                            doc.body.classList.add('dark-theme');
                        } else {
                            doc.body.classList.remove('dark-theme');
                        }
                    }
                } catch (e) {
                    // Cross-origin, do nothing
                }
            });

            // Dispatch a custom event for components to listen for theme changes
            const event = new CustomEvent('themeChanged', {
                detail: { dark: document.body.classList.contains('dark-theme') }
            });
            document.dispatchEvent(event);
        };

        // Optionally, listen for dynamically added iframes and apply theme
        const observer = new MutationObserver(() => {
            const dark = document.body.classList.contains('dark-theme');
            document.querySelectorAll('iframe').forEach(iframe => {
                try {
                    const doc = iframe.contentDocument || iframe.contentWindow.document;
                    if (doc && doc.body) {
                        if (dark) {
                            doc.body.classList.add('dark-theme');
                        } else {
                            doc.body.classList.remove('dark-theme');
                        }
                    }
                } catch (e) {
                    // Cross-origin, do nothing
                }
            });
        });
        observer.observe(document.body, { childList: true, subtree: true });

        function toggleTheme() {
            document.body.classList.toggle('dark-theme');
            // Optionally, save theme preference to localStorage
            if (document.body.classList.contains('dark-theme')) {
                localStorage.setItem('theme', 'dark');
            } else {
                localStorage.setItem('theme', 'light');
            }
        }

        // On page load, apply saved theme
        window.addEventListener('DOMContentLoaded', () => {
            if (localStorage.getItem('theme') === 'dark') {
                document.body.classList.add('dark-theme');
            }
        });